package com.example.padmapper

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.graphics.drawable.Icon
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager

class OverlayService : Service() {
    companion object { const val TOGGLE = "toggle"; const val STOP = "stop" }

    private var wm: WindowManager? = null
    private var pad: PadView? = null
    private var lp: WindowManager.LayoutParams? = null
    private var hidden = false

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        when {
            i?.action == STOP -> stopSelf()
            pad == null -> show()
            i?.action == TOGGLE -> toggle()
        }
        return START_NOT_STICKY
    }

    private fun pi(a: String) = PendingIntent.getService(
        this, a.hashCode(), Intent(this, OverlayService::class.java).setAction(a),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    private fun show() {
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("pad", "Gamepad overlay", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "pad")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("Xbox Pad is on")
            .setContentText("Hide the pad to tap the game, or stop it")
            .addAction(Notification.Action.Builder(Icon.createWithResource(this, android.R.drawable.ic_menu_view), "Hide / show", pi(TOGGLE)).build())
            .addAction(Notification.Action.Builder(Icon.createWithResource(this, android.R.drawable.ic_delete), "Stop", pi(STOP)).build())
            .setOngoing(true).build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return }
        val l = WindowManager.LayoutParams(
            -1, -1, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        l.gravity = Gravity.TOP or Gravity.START
        l.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        wm = getSystemService(WindowManager::class.java)
        pad = PadView(this).also { wm!!.addView(it, l) }
        lp = l
    }

    private fun toggle() {
        val l = lp ?: return
        val v = pad ?: return
        hidden = !hidden
        if (hidden) {
            v.release(); v.alpha = 0f
            l.flags = l.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        } else {
            v.alpha = 1f
            l.flags = l.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
        }
        wm?.updateViewLayout(v, l)
    }

    override fun onDestroy() {
        pad?.release()
        pad?.let { try { wm?.removeView(it) } catch (_: Throwable) {} }
        pad = null
        super.onDestroy()
    }
}
