package com.example.padmapper

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.sign

class PadView(ctx: Context) : View(ctx) {
    private class C(
        val label: String, val x: Float, val y: Float, val r: Float,
        val key: Int = 0, val axis: Int = -1, val stick: Int = -1,
        val dpad: Boolean = false, val color: Int = Color.WHITE
    ) { var kx = 0f; var ky = 0f }

    private val cs = ArrayList<C>()
    private val owner = HashMap<Int, C>()
    private var keys: Set<Int> = emptySet()
    private var ax = FloatArray(8)
    private val dirs = listOf(0 to -1, 0 to 1, -1 to 0, 1 to 0)
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textAlign = Paint.Align.CENTER; isFakeBoldText = true }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        release()
        val u = minOf(h.toFloat(), w / 2.2f)
        val t = h - u
        fun fl(f: Float) = f * u
        fun fr(f: Float) = w - f * u
        fun fy(f: Float) = t + f * u
        val fb = .085f * u
        val sm = .075f * u
        val tiny = .05f * u
        cs.clear()
        cs += C("", fl(.26f), fy(.62f), .17f * u, stick = 0)
        cs += C("", fr(.78f), fy(.74f), .15f * u, stick = 1)
        cs += C("", fl(.62f), fy(.80f), .15f * u, dpad = true)
        cs += C("A", fr(.30f), fy(.71f), fb, KeyEvent.KEYCODE_BUTTON_A, color = 0xFF4CAF50.toInt())
        cs += C("B", fr(.15f), fy(.56f), fb, KeyEvent.KEYCODE_BUTTON_B, color = 0xFFF44336.toInt())
        cs += C("X", fr(.45f), fy(.56f), fb, KeyEvent.KEYCODE_BUTTON_X, color = 0xFF2196F3.toInt())
        cs += C("Y", fr(.30f), fy(.41f), fb, KeyEvent.KEYCODE_BUTTON_Y, color = 0xFFFFC107.toInt())
        cs += C("LT", fl(.18f), fy(.12f), sm, axis = 4)
        cs += C("LB", fl(.38f), fy(.12f), sm, KeyEvent.KEYCODE_BUTTON_L1)
        cs += C("RB", fr(.38f), fy(.12f), sm, KeyEvent.KEYCODE_BUTTON_R1)
        cs += C("RT", fr(.18f), fy(.12f), sm, axis = 5)
        cs += C("VIEW", w / 2f - .17f * u, fy(.10f), tiny, KeyEvent.KEYCODE_BUTTON_SELECT)
        cs += C("XBOX", w / 2f, fy(.10f), tiny, KeyEvent.KEYCODE_BUTTON_MODE)
        cs += C("MENU", w / 2f + .17f * u, fy(.10f), tiny, KeyEvent.KEYCODE_BUTTON_START)
        cs += C("L3", fl(.26f), fy(.32f), tiny, KeyEvent.KEYCODE_BUTTON_THUMBL)
        cs += C("R3", fr(.78f), fy(.44f), tiny, KeyEvent.KEYCODE_BUTTON_THUMBR)
    }

    private fun hit(x: Float, y: Float): C? = cs.firstOrNull {
        it !in owner.values && hypot(x - it.x, y - it.y) < it.r * (if (it.stick >= 0) 1.4f else 1.2f)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val i = e.actionIndex
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN ->
                hit(e.getX(i), e.getY(i))?.let { owner[e.getPointerId(i)] = it }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> owner.remove(e.getPointerId(i))
            MotionEvent.ACTION_CANCEL -> owner.clear()
        }
        update(e)
        return true
    }

    private fun update(e: MotionEvent) {
        val nk = HashSet<Int>()
        val na = FloatArray(8)
        for (k in cs) { k.kx = 0f; k.ky = 0f }
        for ((pid, k) in owner) {
            val i = e.findPointerIndex(pid)
            if (i < 0) continue
            val dx = (e.getX(i) - k.x) / k.r
            val dy = (e.getY(i) - k.y) / k.r
            val m = hypot(dx, dy)
            when {
                k.stick >= 0 -> {
                    val s = if (m > 1f) 1f / m else 1f
                    k.kx = dx * s; k.ky = dy * s
                    na[k.stick * 2] = k.kx; na[k.stick * 2 + 1] = k.ky
                }
                k.dpad -> if (m > .3f) {
                    if (abs(dx) > .38f * m) na[6] = sign(dx)
                    if (abs(dy) > .38f * m) na[7] = sign(dy)
                }
                k.axis >= 0 -> na[k.axis] = 1f
                else -> nk += k.key
            }
        }
        for (k in nk - keys) Injector.key(k, true)
        for (k in keys - nk) Injector.key(k, false)
        if (!na.contentEquals(ax)) Injector.axes(na)
        keys = nk; ax = na
        invalidate()
    }

    fun release() {
        owner.clear()
        for (k in keys) Injector.key(k, false)
        if (ax.any { it != 0f }) Injector.axes(FloatArray(8))
        keys = emptySet(); ax = FloatArray(8)
        for (k in cs) { k.kx = 0f; k.ky = 0f }
        invalidate()
    }

    override fun onDraw(c: Canvas) {
        val on = owner.values
        for (k in cs) {
            p.style = Paint.Style.FILL
            p.color = k.color; p.alpha = if (k in on) 170 else 60
            c.drawCircle(k.x, k.y, k.r, p)
            p.style = Paint.Style.STROKE; p.strokeWidth = k.r * .06f
            p.color = Color.WHITE; p.alpha = 150
            c.drawCircle(k.x, k.y, k.r, p)
            p.style = Paint.Style.FILL
            when {
                k.stick >= 0 -> { p.alpha = 150; c.drawCircle(k.x + k.kx * k.r, k.y + k.ky * k.r, k.r * .42f, p) }
                k.dpad -> for ((dx, dy) in dirs) {
                    val act = (dx != 0 && ax[6] == dx.toFloat()) || (dy != 0 && ax[7] == dy.toFloat())
                    p.alpha = if (act) 220 else 80
                    c.drawCircle(k.x + dx * k.r * .6f, k.y + dy * k.r * .6f, k.r * .24f, p)
                }
                else -> {
                    txt.textSize = k.r * (if (k.label.length > 2) .5f else .85f)
                    c.drawText(k.label, k.x, k.y - (txt.ascent() + txt.descent()) / 2, txt)
                }
            }
        }
    }
}
