package com.example.padmapper

import android.content.pm.PackageManager
import android.os.IBinder
import android.os.SystemClock
import android.view.InputDevice
import android.view.InputEvent
import android.view.KeyEvent
import android.view.MotionEvent
import org.lsposed.hiddenapibypass.HiddenApiBypass
import rikka.shizuku.Shizuku
import rikka.shizuku.ShizukuBinderWrapper
import rikka.shizuku.SystemServiceHelper
import java.lang.reflect.Method
import java.util.concurrent.Executors

/** Sends gamepad key/axis events to the focused app through Shizuku (shell uid). */
object Injector {
    private val exec = Executors.newSingleThreadExecutor()
    private var svc: Any? = null
    private var inject: Method? = null
    private val props = arrayOf(MotionEvent.PointerProperties().apply { id = 0; toolType = MotionEvent.TOOL_TYPE_UNKNOWN })
    private val coords = arrayOf(MotionEvent.PointerCoords())

    fun ready() = Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED

    private fun init(): Boolean {
        if (inject != null) return true
        return try {
            HiddenApiBypass.addHiddenApiExemptions("L")
            val stub = Class.forName("android.hardware.input.IInputManager\$Stub")
            val binder = ShizukuBinderWrapper(SystemServiceHelper.getSystemService("input"))
            svc = stub.getMethod("asInterface", IBinder::class.java).invoke(null, binder)
            inject = svc!!.javaClass.getMethod("injectInputEvent", InputEvent::class.java, Int::class.javaPrimitiveType)
            true
        } catch (t: Throwable) { false }
    }

    private fun send(e: InputEvent) { try { inject?.invoke(svc, e, 0) } catch (_: Throwable) {} }

    fun key(code: Int, down: Boolean) = exec.execute {
        if (!init()) return@execute
        val t = SystemClock.uptimeMillis()
        send(KeyEvent(t, t, if (down) KeyEvent.ACTION_DOWN else KeyEvent.ACTION_UP, code, 0, 0, -1, 0, 0, InputDevice.SOURCE_GAMEPAD))
    }

    /** v = LX, LY, RX, RY, LT, RT, HatX, HatY */
    fun axes(v: FloatArray) {
        val a = v.copyOf()
        exec.execute {
            if (!init()) return@execute
            val c = coords[0]; c.clear()
            c.setAxisValue(MotionEvent.AXIS_X, a[0]); c.setAxisValue(MotionEvent.AXIS_Y, a[1])
            c.setAxisValue(MotionEvent.AXIS_Z, a[2]); c.setAxisValue(MotionEvent.AXIS_RZ, a[3])
            c.setAxisValue(MotionEvent.AXIS_LTRIGGER, a[4]); c.setAxisValue(MotionEvent.AXIS_BRAKE, a[4])
            c.setAxisValue(MotionEvent.AXIS_RTRIGGER, a[5]); c.setAxisValue(MotionEvent.AXIS_GAS, a[5])
            c.setAxisValue(MotionEvent.AXIS_HAT_X, a[6]); c.setAxisValue(MotionEvent.AXIS_HAT_Y, a[7])
            val t = SystemClock.uptimeMillis()
            val e = MotionEvent.obtain(t, t, MotionEvent.ACTION_MOVE, 1, props, coords, 0, 0, 1f, 1f, -1, 0, InputDevice.SOURCE_JOYSTICK, 0)
            send(e); e.recycle()
        }
    }
}
