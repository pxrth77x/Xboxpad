# Xbox Pad (Shizuku, no root)

On-screen Xbox controller. Sends real gamepad events (A/B/X/Y, LB/RB, LT/RT, sticks, L3/R3,
D-pad hat, View/Xbox/Menu) to the game in front, via Shizuku.

Build: push this folder to a GitHub repo, open Actions > build, download the XboxPad-apk artifact.
Use: start Shizuku, open Xbox Pad, allow Shizuku and overlay, tap Start gamepad, switch to the game.
Notification: "Hide / show" makes the pad touch-through so you can tap game menus.
